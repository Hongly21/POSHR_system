<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>index</title>
</head>
    <frameset rows="8%,92%" frameborder="0" border="0" >
        <frame src="navbar.php" name="">
        <frameset cols="17%,*">
            <frame src="root/Sidemenu.php" name="menu">
            <frame src="view/Dashboard/index.php" name="content">
        </frameset>
    </frameset>
</html>