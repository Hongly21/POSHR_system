<?php
    $con=  new mysqli('localhost','root','','hrsystem');
    if(!$con)
    {
        die('Connection Failed..!');
    }

?>